from frappe.model.document import Document
class AIMessage(Document): pass
